"""Temporary location for setup-multiversion constants."""

USE_EXISTING_RELEASES_FILE = False
